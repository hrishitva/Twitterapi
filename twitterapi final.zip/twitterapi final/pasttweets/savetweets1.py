import tweepy
from time import sleep
from ast import literal_eval
from configparser import ConfigParser
import os
import pymysql as MySQLdb

abspath = os.path.abspath('__file__')
path = os.path.dirname(abspath)

config  = ConfigParser(interpolation=None)
config.read(os.path.join(path,'config.ini'))

keys = config['apivalues']

CONSUMER_KEY = keys.get('consumer_key')
CONSUMER_SECRET = keys.get('consumer_secret')
ACCESS_TOKEN = keys.get('access_token')
ACCESS_SECRET = keys.get('access_token_secret')

def get_api():
    auth = tweepy.auth.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
    auth.set_access_token(ACCESS_TOKEN, ACCESS_SECRET)
    return tweepy.API(auth)

keys = config['dbvalues']

host =  keys.get('host')
port =  int(keys.get('port'))
user =  keys.get('user')
passwd =  keys.get('passwd')
database =  keys.get('database')

query = input("Enter the Search Query: ")
api = get_api()
tweets = api.search_tweets(query+' -filter:retweets',count = 100, tweet_mode = 'extended')
conn = MySQLdb.connect(host=host, port=port, user=user, passwd=passwd, database = database)
c = conn.cursor()
for status in tweets:
    r = c.execute("""SELECT * FROM tweets WHERE tweet_id = %s""",(status.id,))
    if not r:    
        for val in query.split():
            if val.lower() in status.full_text.lower():
                tag = val.lower()
                break
        x = c.execute("""SELECT * FROM number_of_tweets WHERE tags = %s""",(tag,))
        if x:
            r = c.fetchone()
            r[2]+1
            c.execute("""UPDATE number_of_tweets SET number ='%s' WHERE tags = %s """,(r[2]+1,tag,))
        else:
            number = 1
            c.execute("""INSERT INTO number_of_tweets (tags, number) VALUES (%s, %s)""", (tag, number,))

        c.execute("""INSERT INTO tweets (tweet_id, tags, tweet_text) VALUES (%s, %s, %s)""", (status.id, tag, status.full_text,))

        x = c.execute("""SELECT * FROM number_of_tweets""")
        x = c.fetchall()
        with open('notepadfile.txt','w') as file:
            pass
        for a in x:
            with open('notepadfile.txt','a') as file:
                string = f'Number of Tweets:  {a[2]},\t Tag/ID:  {a[1]}\n\n'
                file.write(string)
conn.commit()
conn.close()