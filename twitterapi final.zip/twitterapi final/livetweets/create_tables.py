from time import sleep
from ast import literal_eval
from configparser import ConfigParser
import os
import pymysql as MySQLdb

abspath = os.path.abspath('__file__')
path = os.path.dirname(abspath)

config  = ConfigParser(interpolation=None)
config.read(os.path.join(path,'config.ini'))

keys = config['dbvalues']

host =  keys.get('host')
port =  int(keys.get('port'))
user =  keys.get('user')
passwd =  keys.get('passwd')
database =  keys.get('database')

conn = MySQLdb.connect(host=host, port=port, user=user, passwd=passwd, database = database)
c = conn.cursor()

c.execute("""CREATE TABLE tweets (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
tags VARCHAR(30) NOT NULL,
tweet_text VARCHAR(350) NOT NULL,
date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)""")

c.execute("""CREATE TABLE number_of_tweets (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
tags VARCHAR(30) NOT NULL,
number INT(7) NOT NULL,
date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)""")

conn.commit()
conn.close()