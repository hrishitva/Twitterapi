import tweepy
from time import sleep
from ast import literal_eval
from configparser import ConfigParser
import os
import pymysql as MySQLdb

abspath = os.path.abspath(__file__)
path = os.path.dirname(abspath)

config  = ConfigParser(interpolation=None)
config.read(os.path.join(path,'config.ini'))

keys = config['apivalues']

CONSUMER_KEY = keys.get('consumer_key')
CONSUMER_SECRET = keys.get('consumer_secret')
ACCESS_TOKEN = keys.get('access_token')
ACCESS_SECRET = keys.get('access_token_secret')

keys = config['dbvalues']

host =  keys.get('host')
port =  int(keys.get('port'))
user =  keys.get('user')
passwd =  keys.get('passwd')
database =  keys.get('database')
keys = config['tags']
track = keys.get('tagslist')
track = literal_eval(track)

class data_retriever(tweepy.Stream):
    def on_status(self, status):
        if hasattr(status, 'retweeted_status'):
            return
        conn = MySQLdb.connect(host=host, port=port, user=user, passwd=passwd, database = database)
        c = conn.cursor()
    
        if hasattr(status, 'extended_tweet'):
            for val in track:
                if val.lower() in status.extended_tweet['full_text'].lower():
                    tag = val.lower()
                    break

            x = c.execute("""SELECT * FROM number_of_tweets WHERE tags = %s""",(tag,))
            if x:
                r = c.fetchone()
                r[2]+1
                c.execute("""UPDATE number_of_tweets SET number ='%s' WHERE tags = %s """,(r[2]+1,tag,))
            else:
                number = 1
                c.execute("""INSERT INTO number_of_tweets (tags, number) VALUES (%s, %s)""", (tag, number,))

            c.execute("""INSERT INTO tweets (tags, tweet_text) VALUES (%s, %s)""", (tag, status.extended_tweet['full_text'],))

            x = c.execute("""SELECT * FROM number_of_tweets""")
            x = c.fetchall()
            with open('notepadfile.txt','w') as file:
                pass
            for a in x:
                with open('notepadfile.txt','a') as file:
                    string = f'Number of Tweets:  {a[2]},\t Tag/ID:  {a[1]}\n\n'
                    file.write(string)
        else:
            for val in track:
                if val.lower() in status.text.lower():
                    tag = val.lower()
                    break
            x = c.execute("""SELECT * FROM number_of_tweets WHERE tags = %s""",(tag,))
            if x:
                r = c.fetchone()
                r[2]+1
                c.execute("""UPDATE number_of_tweets SET number ='%s' WHERE tags = %s """,(r[2]+1,tag,))
            else:
                number = 1
                c.execute("""INSERT INTO number_of_tweets (tags, number) VALUES (%s, %s)""", (tag, number,))

            c.execute("""INSERT INTO tweets (tags, tweet_text) VALUES (%s, %s)""", (tag, status.text,))

            x = c.execute("""SELECT * FROM number_of_tweets""")
            x = c.fetchall()
            with open('notepadfile.txt','w') as file:
                pass
            for a in x:
                with open('notepadfile.txt','a') as file:
                    string = f'Number of Tweets:  {a[2]},\t Tag/ID:  {a[1]}\n\n'
                    file.write(string)
            
        conn.commit()
        conn.close()
        
        

        

# Initialize instance of the subclass
printer = data_retriever(
    CONSUMER_KEY, CONSUMER_SECRET,
    ACCESS_TOKEN, ACCESS_SECRET
)
# Filter realtime Tweets by keyword
# track = keys.get('tagslist')
printer.filter(track=track)