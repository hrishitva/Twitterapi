import tweepy
from time import sleep
from ast import literal_eval
from configparser import ConfigParser
import os
import pymysql as MySQLdb

abspath = os.path.abspath(__file__)
path = os.path.dirname(abspath)

config  = ConfigParser(interpolation=None)
config.read(os.path.join(path,'config.ini'))

keys = config['apivalues']

CONSUMER_KEY = keys.get('consumer_key')
CONSUMER_SECRET = keys.get('consumer_secret')
ACCESS_TOKEN = keys.get('access_token')
ACCESS_SECRET = keys.get('access_token_secret')


def get_api():

    auth01 = tweepy.auth.OAuthHandler(CONSUMER_KEY, CONSUMER_SECRET)
    auth01.set_access_token(ACCESS_TOKEN, ACCESS_SECRET)
    api = tweepy.API(auth01, wait_on_rate_limit=True)
    return api

api = get_api()

me = api.verify_credentials()
print (me.screen_name)